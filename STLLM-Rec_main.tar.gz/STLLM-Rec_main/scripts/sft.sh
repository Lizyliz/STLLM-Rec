#!/bin/bash
# LLM 全参 SFT（LLaMA-Factory, deepspeed ZeRO-2），超参与论文实验一致
# 用法: bash scripts/sft.sh <init_model> <dataset_name> <output_dir> [num_gpus]
set -e
cd "$(dirname "$0")/.."

MODEL=$1
DATASET=$2
OUT=$3
NGPU=${4:-${NGPU:-3}}

deepspeed --num_gpus $NGPU --master_port=9901 src/train_bash.py \
    --deepspeed ds_config.json \
    --stage sft \
    --model_name_or_path $MODEL \
    --do_train \
    --dataset_dir data \
    --dataset $DATASET \
    --template llama2 \
    --finetuning_type full \
    --output_dir $OUT \
    --overwrite_cache \
    --per_device_train_batch_size 1 \
    --gradient_accumulation_steps 16 \
    --per_device_eval_batch_size 1 \
    --preprocessing_num_workers 8 \
    --lr_scheduler_type cosine \
    --logging_steps 10 \
    --learning_rate 1e-5 \
    --num_train_epochs 1.0 \
    --plot_loss \
    --cutoff_len 1024 \
    --bf16 \
    --overwrite_output_dir \
    --eval_steps 500 \
    --evaluation_strategy epoch \
    --val_size 5 \
    --save_strategy epoch
