#!/bin/bash
# STLLM-Rec 主实验完整流程（Toys 数据集，T=2 轮自训练）
# 需先把两个基座模型放到 models/ 下（或软链接）：
#   models/Llama-3.1-8B-Instruct   生成 LLM
#   models/MetaMath-Mistral-7B     价值模型基座
set -e
cd "$(dirname "$0")/.."
export STLLM_VM_BASE=$PWD/models/MetaMath-Mistral-7B
D=data/toys
O=outputs
NGPU=${NGPU:-3}
mkdir -p $O

# ---------- 第 0 轮：初始价值模型 V0（固定步数标签 1/0.67/0.33/0） ----------
python stllm/train_value.py \
    --train $D/vm_iter0/train.json --val $D/vm_iter0/valid.json --test $D/vm_iter0/test.json \
    --save $O/VM0.pt

# ---------- 第 1 轮：LLM SFT（种子正确推理路径） ----------
bash scripts/sft.sh models/Llama-3.1-8B-Instruct toys_sft_iter1 $O/llm_iter1 $NGPU

# 树搜索 + V0 选择 -> 正/负样本
python stllm/gen.py \
    --base_model $O/llm_iter1 --vm_ckpt $O/VM0.pt \
    --test_data_path $D/test1000.json \
    --result_json_data $O/iter1_metrics.json \
    --correct_result_json $O/iter1_right.json \
    --incorrect_result_json $O/iter1_false.json

# 构造第 2 轮数据（正样本 -> SFT；正+负 -> 价值模型）
# 如需直接复用论文实验时的第 2 轮数据，跳过这一步，并把下面两处路径换成 toys_sft_iter2 / $D/vm_iter1
mkdir -p $O/vm_iter1
python stllm/build_iter_data.py \
    --right $O/iter1_right.json --false $O/iter1_false.json \
    --sft_out $D/sft_iter2_new.json --vm_dir $O/vm_iter1
python - <<'EOF'
import json
p = "data/dataset_info.json"
d = json.load(open(p))
d["toys_sft_iter2_new"] = dict(d["toys_sft_iter2"], file_name="toys/sft_iter2_new.json")
json.dump(d, open(p, "w"), indent=2)
EOF

# ---------- 第 2 轮：LLM 与价值模型继续自训练 ----------
bash scripts/sft.sh $O/llm_iter1 toys_sft_iter2_new $O/llm_iter2 $NGPU
python stllm/train_value.py \
    --train $O/vm_iter1/train_set.json --val $O/vm_iter1/val_set.json --test $O/vm_iter1/test_set.json \
    --init $O/VM0.pt --save $O/VM1.pt

# ---------- 最终评测：AUC / Accuracy，并保存推理路径（解释） ----------
python stllm/gen.py \
    --base_model $O/llm_iter2 --vm_ckpt $O/VM1.pt \
    --test_data_path $D/test1000.json \
    --result_json_data $O/final_metrics.json \
    --correct_result_json $O/final_right.json \
    --incorrect_result_json $O/final_false.json
cat $O/final_metrics.json
