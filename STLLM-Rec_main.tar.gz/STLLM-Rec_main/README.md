# STLLM-Rec 主实验（最小可运行版，Toys 数据集）

这个包只保留跑通 STLLM-Rec 主实验所需的代码和数据，数据集只用 Toys。

## 整体流程（`scripts/run_main.sh`，两轮自训练）

1. **第 0 轮：训练初始价值模型 V0**
   用 `data/toys/vm_iter0/` 训练 `stllm/train_value.py`。这部分数据按推理走到第几步打固定分：1 / 0.67 / 0.33 / 0，对应论文中"初始价值模型没有标注数据，用固定分值构造"的做法。

2. **第 1 轮：LLM 全参微调**
   用 Llama-3.1-8B-Instruct 在 `sft_iter1.json` 上微调。这份数据有 2000 条带三步推理路径的正确样本，微调后得到 `llm_iter1`。

3. **树搜索生成正负样本**
   `stllm/gen.py` 用 `llm_iter1` 分三步推理：先总结用户偏好，再介绍目标物品，最后判断两者是否匹配并输出 Yes/No。每一步生成多个候选，由 V0 打分选出最优。最终答案正确的路径算正样本，错误的算负样本。

4. **构造第 2 轮数据**
   `stllm/build_iter_data.py` 把正样本整理成下一轮 LLM 的微调数据，再把正、负样本一起按 8:1:1 划分，作为价值模型的训练数据。

5. **第 2 轮：继续自训练**
   LLM 从 `llm_iter1` 出发，在新的正样本上再微调一次，得到 `llm_iter2`。价值模型从 V0 出发，在正负样本上继续训练，得到 V1。

6. **最终评测**
   用 `llm_iter2` 和 V1 再跑一次树搜索，把 AUC / Accuracy 输出到 `outputs/final_metrics.json`，同时保存每条样本的推理路径，也就是生成的解释。

## 目录说明

| 路径 | 作用 |
|---|---|
| `src/` | 旧版 LLaMA-Factory（llmtuner），只用来做 LLM 微调 |
| `stllm/train_value.py` | 价值模型：MetaMath-Mistral-7B 加一个线性层，用 MSE 回归分数；含训练入口和打分函数 |
| `stllm/gen.py` | 三步树搜索加价值模型选择，计算 AUC/Accuracy，保存正确和错误的推理路径 |
| `stllm/build_iter_data.py` | 由搜索结果生成下一轮数据：正样本用于 SFT，正负样本一起用于价值模型 |
| `scripts/sft.sh` | 微调启动脚本，超参与原实验一致：lr 1e-5，1 个 epoch，cutoff 1024，bf16，ZeRO-2 |
| `scripts/run_main.sh` | 完整流程：两轮自训练加最终评测 |
| `data/dataset_info.json` | 注册 SFT 数据集（`toys_sft_iter1`、`toys_sft_iter2`） |
| `data/toys/sft_iter1.json` | 第 1 轮 SFT 数据（2000 条） |
| `data/toys/vm_iter0/` | 初始价值模型 V0 的训练、验证、测试数据 |
| `data/toys/sft_iter2.json`、`data/toys/vm_iter1/` | 原实验第 2 轮实际用过的数据（SFT 502 条；价值模型 800/100/100 条）。想直接复用时，把 `run_main.sh` 中第 2 轮的路径换成 `toys_sft_iter2` 和 `data/toys/vm_iter1` |
| `data/toys/test1000.json` | 评测集，1000 条，Yes 和 No 各 500 |
| `models/` | 放两个基座模型（需自行准备，未打包） |
| `outputs/` | 运行产物：价值模型权重、微调后的 LLM、评测结果 |

## 运行方法

```bash
pip install -r requirements.txt
ln -s /path/to/Llama-3.1-8B-Instruct models/Llama-3.1-8B-Instruct
ln -s /path/to/MetaMath-Mistral-7B   models/MetaMath-Mistral-7B
NGPU=3 bash scripts/run_main.sh      # 结果写到 outputs/final_metrics.json
```

单独运行某一步的示例：

```bash
# 训练价值模型
STLLM_VM_BASE=models/MetaMath-Mistral-7B python stllm/train_value.py \
    --train data/toys/vm_iter0/train.json --val data/toys/vm_iter0/valid.json \
    --test data/toys/vm_iter0/test.json --save outputs/VM0.pt

# LLM 微调
bash scripts/sft.sh models/Llama-3.1-8B-Instruct toys_sft_iter1 outputs/llm_iter1 3

# 树搜索 + 评测
STLLM_VM_BASE=models/MetaMath-Mistral-7B python stllm/gen.py \
    --base_model outputs/llm_iter1 --vm_ckpt outputs/VM0.pt \
    --test_data_path data/toys/test1000.json \
    --result_json_data outputs/metrics.json \
    --correct_result_json outputs/right.json \
    --incorrect_result_json outputs/false.json
```

## 环境与资源

- 环境：Python 3.9，CUDA 12.1，依赖版本见 `requirements.txt`（与原实验的 conda 环境 `py39` 一致）。
- 显存：8B 全参微调在原实验中用的是 3 张 A800 80G。价值模型的训练和打分用单卡 80G 即可。

## 注意

原实验第 2 轮数据是在 `test1000.json` 上做树搜索得到的，`sft_iter2.json` 的 502 条样本都在 `test1000.json` 中。`run_main.sh` 保持了这一做法。如果希望训练和测试严格分开，把第 1 轮树搜索的 `--test_data_path` 换成与测试集不重叠的数据。
