import sys
import fire
import numpy as np
import torch
import transformers
import json
import os
import re
from tqdm import tqdm
from transformers import GenerationConfig, LlamaForCausalLM, AutoTokenizer
from sklearn.metrics import roc_auc_score, log_loss, accuracy_score
import json
from tqdm import tqdm
import time
from datetime import datetime
torch.set_num_threads(1)
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'

if torch.cuda.is_available():
    device = "cuda:0"
else:
    device = "cpu"

try:
    if torch.backends.mps.is_available():
        device = "mps"
except:  # noqa: E722
    pass


import os
import json
import torch
import transformers
from tqdm import tqdm
from transformers import GenerationConfig, LlamaForCausalLM, AutoTokenizer
from sklearn.metrics import roc_auc_score, log_loss, accuracy_score
from train_value import load_model as load_scoring_model, score_text, load_tokenizer, VM_CKPT # 引入评分模型相关函数


def main(
    load_8bit: bool = False,
    base_model: str = "/media/disk1/fordata/web_server/XXXX-1/LLM_models/llama-2-hf/Llama-2-7b-hf/",
    test_data_path: str = "/home/web_server/XXXX-1/codes/RRecAgent/LLaMA-Factory/data/amazon_test.json",
    result_json_data: str = "/home/web_server/XXXX-1/codes/RRecAgent/LLaMA-Factory/eval_result/llama-7B-base.json",
    correct_result_json: str = "/home/web_server/XXXX-1/codes/RRecAgent/LLaMA-Factory/eval_result/correct_predictions.json",
    incorrect_result_json: str = "/home/web_server/XXXX-1/codes/RRecAgent/LLaMA-Factory/eval_result/incorrect_predictions.json",
    vm_ckpt: str = VM_CKPT,
    batch_size: int = 32,
    share_gradio: bool = False,
):
    assert (
        base_model
    ), "Please specify a --base_model, e.g. --base_model='decapoda-research/llama-7b-hf'"

    print(f"\n=== 开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===")
    start_time = time.time()

    # 加载评分模型
    print("正在加载评分模型...")
    scoring_model = load_scoring_model(weight_path=vm_ckpt)  # 价值模型，见 train_value.py
    scoring_model.to(device)
    scoring_model.eval()

    scoring_tokenizer = load_tokenizer()  # 从train_value.py中加载评分模型的分词器
    print("评分模型加载完成")



    seed = 1024 #temp_list[-2]
    sample = 1 #temp_list[-1]
    
    print("正在加载生成模型...")
    tokenizer = AutoTokenizer.from_pretrained(base_model,)
    if "cuda" in device:
        model = LlamaForCausalLM.from_pretrained(
            base_model,
            torch_dtype=torch.float16,
            device_map='auto'
        )
    print("生成模型加载完成")



    tokenizer.padding_side = "left"
    # unwind broken decapoda-research config
    model.config.pad_token_id = tokenizer.pad_token_id = 0  # </s>
    model.config.bos_token_id = 1
    model.config.eos_token_id = 2

    if not load_8bit:
        model.half()  # seems to fix bugs for some users.

    model.eval()
    if torch.__version__ >= "2" and sys.platform != "win32":
        model = torch.compile(model)
    
    print("模型初始化完成，开始加载测试数据...")

    def evaluate_step(
        instructions,
        inputs=None,
        temperature=0,
        top_p=1.0,
        top_k=40,
        num_beams=1,
        max_new_tokens=1024,
        cutoff_len=1024,
        batch_size=1,
        num_candidates=3,
        step_index=0,
        **kwargs,
    ):
        """
        生成给定步骤的多个候选答案，并根据评分模型选择最优的一个。
        """
        prompt = [generate_prompt(instruction, input, step_index) for instruction, input in zip(instructions, inputs)]
        inputs_encoded = tokenizer(prompt, return_tensors="pt", padding=True, truncation=True, max_length=cutoff_len).to(device)
        
        generation_config = GenerationConfig(
            temperature=temperature,
            top_p=top_p,
            num_beams=num_beams,
            **kwargs,
        )
        
        candidates = []
        with torch.no_grad():
            for _ in range(num_candidates):  # 生成num_candidates个候选答案
                generation_output = model.generate(
                    **inputs_encoded,
                    generation_config=generation_config,
                    return_dict_in_generate=True,
                    output_scores=True,
                    max_new_tokens=max_new_tokens,
                )
                s = generation_output.sequences
                generated_sequences_trimmed = [seq[inputs_encoded["input_ids"].shape[1]:] for seq in s]
                outputs = tokenizer.batch_decode(generated_sequences_trimmed, skip_special_tokens=True)
                candidates.extend(outputs)
        

        # 使用评分模型选择最佳候选，并获取其得分
        best_candidate, best_score = select_best_candidate(candidates, scoring_model, scoring_tokenizer)
        return best_candidate, best_score  # 返回最佳候选和其得分

    def select_best_candidate(candidates, scoring_model, tokenizer):
        """
        使用评分模型从候选答案中选择评分最高的一个。
        """
        scores = [score_text(text=candidate, model=scoring_model, tokenizer=tokenizer) for candidate in candidates]
        best_idx = np.argmax(scores)
        return candidates[best_idx], scores[best_idx]  # 返回最佳候选和其得分
    
    # 主流程修改以支持多步生成和选择
    final_outputs = []
    logits = []
    gold_labels = []

    with open(test_data_path, 'r') as f:
        test_data = json.load(f)
        instructions = [_['instruction'] for _ in test_data]
        inputs = [_['input'] for _ in test_data]
        gold_labels = [int(_['Output'] == 'Yes') for _ in test_data]

    print(f"测试数据加载完成，共 {len(test_data)} 条样本")
    print(f"开始推理评估: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    inference_start_time = time.time()

    correct_predictions = []
    incorrect_predictions = []

    # 修改主流程以包含评分信息
    for i, (instruction, input) in tqdm(enumerate(zip(instructions, inputs)), total=len(instructions)):
        best_first_step, score_first = evaluate_step([instruction], [input], step_index=0)
        best_second_step, score_second = evaluate_step([best_first_step], [input], step_index=1)
        best_third_step, score_third = evaluate_step([best_second_step], [input], step_index=2)

        final_outputs.append(best_third_step)

        predicted_label = 1 if "Yes" in best_third_step else 0
        prediction_info = {
            "instruction": instruction,
            "input": input,
            "prediction": best_third_step,
            "label": gold_labels[i],
            "scores": [score_first, score_second, score_third],  # 添加每步的评分
            "score": score_third
        }

        if predicted_label == gold_labels[i]:
            correct_predictions.append(prediction_info)
        else:
            incorrect_predictions.append(prediction_info)

    inference_time = time.time() - inference_start_time
    print(f"推理完成: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"推理耗时: {inference_time:.2f}秒 ({inference_time/60:.2f}分钟)")
    print(f"平均每个样本耗时: {inference_time/len(test_data):.2f}秒")

    # 计算并保存结果
    pred = [1 if "Yes" in output else 0 for output in final_outputs]
    result_auc = roc_auc_score(gold_labels, pred)
    result_logloss = log_loss(gold_labels, pred)
    result_accuracy = accuracy_score(gold_labels, pred)

    results = {
        "AUC": result_auc,
        "LogLoss": result_logloss,
        "Accuracy": result_accuracy
    }

    # 将整体评估结果保存到一个JSON文件中
    with open(result_json_data, 'w') as f:
        json.dump(results, f, indent=4)
        print("AUC: ", result_auc)
        print("LogLoss: ", result_logloss)
        print("Accuracy: ", result_accuracy)

    # 分别保存正确和错误的预测结果
    with open(correct_result_json, 'w') as f:
        json.dump(correct_predictions, f, indent=4)
        print(f"Correct predictions saved to {correct_result_json}")

    with open(incorrect_result_json, 'w') as f:
        json.dump(incorrect_predictions, f, indent=4)
        print(f"Incorrect predictions saved to {incorrect_result_json}")

    total_time = time.time() - start_time
    print(f"\n=== 任务完成: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===")
    print(f"总耗时: {total_time:.2f}秒 ({total_time/60:.2f}分钟 / {total_time/3600:.2f}小时)")
    print(f"正确预测: {len(correct_predictions)} 条")
    print(f"错误预测: {len(incorrect_predictions)} 条")


def generate_prompt(instruction, input=None, step_index=0):
    steps = [
        "The first step is to summarize user information based on their interaction history items.",
        "The second step is to introduce the target new item and detail its features precisely. In addition, integrate information about items related to the current target new item to enhance understanding of its context and potential applications.",
        "The third step is to contemplate the alignment between the user's profile and the features of the target item."
    ]
    current_step = steps[step_index]
    return f"""[INST] <<SYS>>
    As an AI model developed to analyze consumer behavior, your task is to first determine whether the user will purchase the target item. If the answer is yes, respond with "Yes." If the answer is no, respond with "No." Then, provide the reasoning process based on the following steps:
    {current_step}
    Please generate a chain of thought for the specified step only.
    <</SYS>>

    {instruction}
    {input} [/INST]"""


if __name__ == "__main__":
    fire.Fire(main)
