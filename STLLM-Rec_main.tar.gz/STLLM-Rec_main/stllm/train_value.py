import os

os.environ.setdefault('CUDA_VISIBLE_DEVICES', '0')
import json
import argparse
import numpy as np
import torch
import torch.nn as nn
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer
from torch.optim import AdamW
from torch.utils.data import DataLoader, Dataset

max_length = 900

ROOT = os.path.dirname(os.path.abspath(__file__))
VM_BASE = os.environ.get("STLLM_VM_BASE", os.path.join(ROOT, "..", "models", "MetaMath-Mistral-7B"))
VM_CKPT = os.environ.get("STLLM_VM_CKPT", os.path.join(ROOT, "..", "outputs", "VM_best_checkpoint.pt"))

# Load the pre-trained Mistral-7b model and tokenizer
tokenizer = AutoTokenizer.from_pretrained(VM_BASE, trust_remote_code=True)
base_model = AutoModelForCausalLM.from_pretrained(VM_BASE, trust_remote_code=True, torch_dtype=torch.bfloat16).cuda()

def load_tokenizer(model_path=VM_BASE):
    """加载分词器"""
    return AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)

# Custom Dataset class
class MyDataset(Dataset):
    def __init__(self, data_js, tokenizer):
        self.data_js = data_js
        self.tokenizer = tokenizer

    def __len__(self):
        return len(self.data_js)

    def __getitem__(self, idx):
        prompt_answer = self.data_js[idx]['prompt_answer']
        label = self.data_js[idx]['label']

        encoded_pair = self.tokenizer.encode_plus(
            prompt_answer,
            padding='max_length',
            max_length=max_length,  # Set the max length
            truncation=True,
            return_tensors='pt',  # Return PyTorch Tensor format
        )

        return {
            'input_ids': encoded_pair['input_ids'].squeeze(),
            'attention_mask': encoded_pair['attention_mask'].squeeze(),
            'label': label
        }


class Mistral_VM(nn.Module):
    def __init__(self, base, vocab_size=32000):
        super(Mistral_VM, self).__init__()
        self.base_model = base
        self.LN = nn.Linear(vocab_size, 1)

    def forward(self, input_ids, attention_mask):
        outputs = self.base_model(input_ids=input_ids, attention_mask=attention_mask).logits[:, -1, :]
        value_outputs = self.LN(outputs)
        return value_outputs.squeeze(dim=1)


def load_model(model_path=VM_BASE, weight_path=VM_CKPT):
    """加载训练好的模型"""
    VM = Mistral_VM(base_model, vocab_size=base_model.config.vocab_size)
    VM.load_state_dict(torch.load(weight_path))
    VM.to("cuda" if torch.cuda.is_available() else "cpu")
    VM.eval()
    return VM

def score_text(text, model, tokenizer, max_length=900):
    """对给定文本进行评分"""
    encoded_input = tokenizer.encode_plus(
        text,
        padding='max_length',
        max_length=max_length,
        truncation=True,
        return_tensors='pt'
    )
    input_ids = encoded_input['input_ids'].to("cuda" if torch.cuda.is_available() else "cpu")
    attention_mask = encoded_input['attention_mask'].to("cuda" if torch.cuda.is_available() else "cpu")

    with torch.no_grad():
        outputs = model(input_ids=input_ids, attention_mask=attention_mask)
    predicted_score = outputs.item()
    processed_score = min(max(predicted_score, 0), 1)
    return processed_score


def read_json(source):
    json_list = []
    with open(source, 'r', encoding='utf-8') as f:
        for line in f:
            json_list.append(json.loads(line))
    return json_list


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", required=True)
    parser.add_argument("--val", required=True)
    parser.add_argument("--test", required=True)
    parser.add_argument("--save", default=VM_CKPT)
    parser.add_argument("--init", default=None, help="上一轮价值模型权重（自训练时继续训练）")
    parser.add_argument("--epochs", type=int, default=2)  # 2 or 3
    parser.add_argument("--lr", type=float, default=3e-6)
    parser.add_argument("--batch_size", type=int, default=3)
    args = parser.parse_args()

    train_json = read_json(args.train)
    val_json = read_json(args.val)
    test_json = read_json(args.test)

    # Create a custom dataset
    train_dataset = MyDataset(train_json, tokenizer)
    val_dataset = MyDataset(val_json, tokenizer)
    test_dataset = MyDataset(test_json, tokenizer)

    # Create data loaders
    train_dataloader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
    val_dataloader = DataLoader(val_dataset, batch_size=args.batch_size)
    test_dataloader = DataLoader(test_dataset, batch_size=args.batch_size)

    # Set device and model
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    vocab_size = base_model.config.vocab_size
    VM = Mistral_VM(base_model, vocab_size)
    if args.init:
        VM.load_state_dict(torch.load(args.init))
    VM.to(device)

    # Define loss function and optimizer
    criterion = nn.MSELoss()
    optimizer = AdamW(VM.parameters(), lr=args.lr)
    num_epochs = args.epochs
    # Training and validation loop
    best_val_loss = 10000000
    for epoch in range(num_epochs):
        print(f"{epoch}/{num_epochs} training")
        # Training
        VM.train()
        train_loss = 0.0
        for batch in tqdm(train_dataloader):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['label'].to(dtype=torch.float32).to(device)

            optimizer.zero_grad()
            outputs = VM(input_ids=input_ids, attention_mask=attention_mask)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            train_loss += loss.item()

        avg_train_loss = train_loss / len(train_dataloader)

        # Validation
        VM.eval()
        val_loss = 0.0
        with torch.no_grad():
            for batch in tqdm(val_dataloader):
                input_ids = batch['input_ids'].to(device)
                attention_mask = batch['attention_mask'].to(device)
                labels = batch['label'].to(dtype=torch.float32).to(device)
                outputs = VM(input_ids=input_ids, attention_mask=attention_mask)
                loss = criterion(outputs, labels)
                val_loss += loss.item()

        avg_val_loss = val_loss / len(val_dataloader)

        print(f"Epoch [{epoch + 1}/{num_epochs}]")
        print(f"Train Loss: {avg_train_loss:.4f} | Val Loss: {avg_val_loss:.4f} ")

        # Save best model
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            torch.save(VM.state_dict(), args.save)

    print("Training complete!")

    # Load the best model for inference
    VM.load_state_dict(torch.load(args.save))
    VM.eval()

    # Perform inference
    test_preds = []
    test_labels = []
    with torch.no_grad():
        for batch in tqdm(test_dataloader):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['label'].to(dtype=torch.float32).to(device)
            outputs = VM(input_ids=input_ids, attention_mask=attention_mask)
            test_preds.extend(outputs.tolist())
            test_labels.extend(labels.tolist())

    cnt = 0
    for i in range(len(test_preds)):
        if abs(min(max(test_preds[i], 0), 1) - test_labels[i]) <= 0.1:
            cnt += 1
    test_acc = cnt / len(test_preds)
    print(f"Test accuracy: {test_acc:.4f}")
