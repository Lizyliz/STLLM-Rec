"""
由 gen.py（树搜索 + 价值模型）的输出构造下一轮自训练数据：
  1) 正样本 -> LLM SFT 数据（instruction / input / Output），写入 LLaMA-Factory 数据目录
  2) 正样本 + 负样本 -> 价值模型训练数据（prompt_answer / label），按 8:1:1 划分
对应原工程 eval_result/toys_path 下的 14.py / 15.py / 16.py。
"""
import json
import random
import argparse


def load_json(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def to_vm_items(data):
    results = []
    for item in data:
        prompt_answer = f"Problem:{item['instruction']}\n{item['input']}\n\nSolution:{item['prediction'].replace('1.', 'Step 1:').replace('2.', 'Step 2:').replace('3.', 'Step 3:')}"
        results.append({"prompt_answer": prompt_answer, "label": item['score']})
    return results


def write_jsonl(data, file_name):
    with open(file_name, 'w', encoding='utf-8') as file:
        for item in data:
            file.write(json.dumps(item, ensure_ascii=False) + '\n')


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--right", required=True, help="gen.py 的 correct_result_json")
    parser.add_argument("--false", required=True, help="gen.py 的 incorrect_result_json")
    parser.add_argument("--sft_out", required=True, help="下一轮 LLM SFT 数据（dataset_info.json 中登记的文件）")
    parser.add_argument("--vm_dir", required=True, help="价值模型数据输出目录")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    right_data = load_json(args.right)
    false_data = load_json(args.false)

    # 1) 正样本 -> SFT（prediction 重命名为 Output，去掉 label 等字段）
    sft_data = [{"instruction": x["instruction"], "input": x["input"], "Output": x["prediction"]} for x in right_data]
    with open(args.sft_out, 'w', encoding='utf-8') as f:
        json.dump(sft_data, f, ensure_ascii=False, indent=4)

    # 2) 正负样本 -> 价值模型数据
    combined_data = to_vm_items(right_data) + to_vm_items(false_data)
    random.seed(args.seed)
    random.shuffle(combined_data)

    total_length = len(combined_data)
    train_size = int(0.8 * total_length)
    val_size = int(0.1 * total_length)

    write_jsonl(combined_data[:train_size], f"{args.vm_dir}/train_set.json")
    write_jsonl(combined_data[train_size:train_size + val_size], f"{args.vm_dir}/val_set.json")
    write_jsonl(combined_data[train_size + val_size:], f"{args.vm_dir}/test_set.json")

    print(f"SFT: {len(sft_data)} -> {args.sft_out}")
    print(f"VM: train {train_size} / val {val_size} / test {total_length - train_size - val_size} -> {args.vm_dir}")
